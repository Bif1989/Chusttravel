
import logging
import os
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

API_TOKEN = os.getenv("API_TOKEN") or "7619198125:AAE2QX6eDsoXic4qlNeSDLwZFc98BhctJsU"

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start', 'help'])
async def send_welcome(message: types.Message):
    await message.reply(
        "Ассалому алайкум! Чустдан чиқувчи турлар рўйхати:

"
        "1) Чуст – Чодак: Сешанба, Пайшанба, Шанба, Якшанба – 180,000 сўм
"
        "2) Чуст – Нанай: Пайшанба – 230,000 сўм
"
        "3) Чорток: Шанба – 300,000 сўм
"
        "4) Самарқанд – Бухоро (Буюртма): 1,600,000 сўм
"
        "   (3 маҳал овқат, меҳмонхона, экскурсиялар киради)
"
        "5) Тошкент (Буюртма): 2 кун – 700,000 сўм

"
        "Админ: @bif89
"
        "Алоқа: +998912924010"
    )

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
